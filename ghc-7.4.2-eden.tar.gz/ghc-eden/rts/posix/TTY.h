/* -----------------------------------------------------------------------------
 *
 * (c) The GHC Team, 1998-2009
 *
 * TTY-related functionality
 *
 * ---------------------------------------------------------------------------*/

#ifndef POSIX_TTY_H
#define POSIX_TTY_H

RTS_PRIVATE void resetTerminalSettings (void);

#endif /* POSIX_TTY_H */
