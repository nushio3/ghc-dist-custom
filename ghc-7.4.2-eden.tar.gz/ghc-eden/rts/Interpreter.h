/* -----------------------------------------------------------------------------
 *
 * (c) The GHC Team, 1998-2002.
 *
 * Prototypes for functions in Interpreter.c
 *
 * ---------------------------------------------------------------------------*/

#ifndef INTERPRETER_H
#define INTERPRETER_H

RTS_PRIVATE Capability *interpretBCO (Capability* cap);

#endif /* INTERPRETER_H */
