#ifndef PS_FILE_H
#define PS_FILE_H

void PutPsFile PROTO((void));
void NextPage PROTO((void)); // for Key.c

#endif /* PS_FILE_H */
