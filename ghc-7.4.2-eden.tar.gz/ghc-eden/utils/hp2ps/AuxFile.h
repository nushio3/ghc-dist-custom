#ifndef AUX_FILE_H
#define AUX_FILE_H

void PutAuxFile PROTO((FILE *));
void GetAuxFile PROTO((FILE *));

#endif /* AUX_FILE_H */
