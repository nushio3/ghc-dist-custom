#ifndef TRACE_ELEMENT_H
#define TRACE_ELEMENT_H

void TraceElement PROTO((void));

#endif /* TRACE_ELEMENT_H */
