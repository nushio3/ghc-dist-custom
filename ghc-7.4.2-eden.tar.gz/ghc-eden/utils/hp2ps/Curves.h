#ifndef CURVES_H
#define CURVES_H

void Curves PROTO((void));
void CurvesInit PROTO((void));

floatish xpage PROTO((floatish));
floatish ypage PROTO((floatish));

#endif /* CURVES_H */
