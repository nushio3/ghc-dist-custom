#ifndef AXES_H
#define AXES_H

void Axes PROTO((void));

#endif /* AXES_H */
