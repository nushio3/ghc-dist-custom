#ifndef SHADE_H
#define SHADE_H

floatish ShadeOf  PROTO((char *));
void     ShadeFor PROTO((char *, floatish));
void     SetPSColour PROTO((floatish));

#endif /* SHADE_H */
