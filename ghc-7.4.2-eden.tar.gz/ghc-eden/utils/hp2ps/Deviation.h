#ifndef DEVIATION_H
#define DEVIATION_H

void Deviation  PROTO((void));
void Identorder PROTO((int));

#endif /* DEVIATION_H */
