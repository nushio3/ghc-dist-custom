#ifndef KEY_H
#define KEY_H

void Key PROTO((void));

#endif /* KEY_H */
