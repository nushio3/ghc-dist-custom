#ifndef MARKS_H
#define MARKS_H

void Marks PROTO((void));

#endif /* MARKS_H */
