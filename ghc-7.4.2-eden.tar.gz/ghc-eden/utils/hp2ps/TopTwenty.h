#ifndef TOP_TWENTY_H
#define TOP_TWENTY_H

void TopTwenty PROTO((void));

#endif /* TOP_TWENTY_H */
