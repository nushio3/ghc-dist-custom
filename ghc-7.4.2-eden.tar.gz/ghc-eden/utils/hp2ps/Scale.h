#ifndef SCALE_H
#define SCALE_H

floatish MaxCombinedHeight PROTO((void));
void     Scale PROTO((void));

#endif /* SCALE_H */
