#ifndef AREA_BELOW_H
#define AREA_BELOW_H

floatish AreaBelow PROTO((void));

#endif /* AREA_BELOW_H */
