#ifndef REORDER_H
#define REORDER_H

void Reorder  PROTO((void));
int  OrderOf  PROTO((char *));
void OrderFor PROTO((char *, int));

#endif /* REORDER_H */
