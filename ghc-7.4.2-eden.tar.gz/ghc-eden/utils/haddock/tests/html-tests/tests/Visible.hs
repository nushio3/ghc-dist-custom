module Visible where
visible :: Int -> Int
visible a = a
