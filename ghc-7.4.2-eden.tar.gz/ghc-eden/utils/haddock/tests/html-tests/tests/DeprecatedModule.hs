-- | Documentation for "DeprecatedModule".
module DeprecatedModule {-# DEPRECATED "Use Foo instead" #-} where

foo :: Int
foo = 23
