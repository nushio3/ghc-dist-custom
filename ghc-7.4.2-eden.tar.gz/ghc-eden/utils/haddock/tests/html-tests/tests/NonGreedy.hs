module NonGreedy where

-- | <url1> <url2>
f :: a
f = undefined
