{-# LANGUAGE TemplateHaskell #-}

module TH2 where

import TH

$( decl )
