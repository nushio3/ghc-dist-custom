module NamedDoc where

-- $foo bar

