-- | Documentation for "ModuleWithWarning".
module ModuleWithWarning {-# WARNING "This is an unstable interface." #-} where

foo :: Int
foo = 23
