module Bug1 where

-- | We should have different anchors for constructors and types\/classes.  This
-- hyperlink should point to the type constructor by default: 'T'.
data T = T

