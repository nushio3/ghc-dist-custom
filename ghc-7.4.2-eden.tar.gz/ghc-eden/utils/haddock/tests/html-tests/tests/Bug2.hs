module Bug2 ( x ) where
import B
x :: A
x = A
