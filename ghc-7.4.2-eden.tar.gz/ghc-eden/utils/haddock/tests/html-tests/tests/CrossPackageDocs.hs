module CrossPackageDocs (map, Monad(..), runInteractiveProcess) where

import System.Process
