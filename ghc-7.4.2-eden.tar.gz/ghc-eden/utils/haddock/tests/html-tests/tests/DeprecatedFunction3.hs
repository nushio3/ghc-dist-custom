module DeprecatedFunction3 where



foo = 23
{-# DEPRECATED foo "use bar instead" #-}
