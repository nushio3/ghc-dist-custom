{-# OPTIONS_HADDOCK hide #-}

module Ticket61_Hidden where

class C a where
  -- | A comment about f
  f :: a
