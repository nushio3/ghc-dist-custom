{-# LANGUAGE MagicHash #-}

module Ticket112 where

import GHC.Prim

-- | ...given a raw 'Addr#' to the string, and the length of the string.
f :: a
f = undefined
