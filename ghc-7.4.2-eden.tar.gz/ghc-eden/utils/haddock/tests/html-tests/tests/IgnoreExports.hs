{-# OPTIONS_HADDOCK ignore-exports #-}
module IgnoreExports (foo) where

-- | documentation for foo
foo :: Int
foo = 23

-- | documentation for bar
bar :: Int
bar = 23
