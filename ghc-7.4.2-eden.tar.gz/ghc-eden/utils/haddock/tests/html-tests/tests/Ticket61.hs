module Ticket61 (module Ticket61_Hidden) where

import Ticket61_Hidden
