{-# OPTIONS_HADDOCK hide #-}

module Hidden where

hidden :: Int -> Int
hidden a = a
