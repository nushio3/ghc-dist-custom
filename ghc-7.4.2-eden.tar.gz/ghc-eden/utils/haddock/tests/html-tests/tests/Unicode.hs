module Unicode where

-- | γλώσσα
x :: Int
x = 1

