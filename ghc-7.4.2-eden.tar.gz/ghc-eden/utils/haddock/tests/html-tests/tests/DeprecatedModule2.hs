module DeprecatedModule2 {-# DEPRECATED "Use Foo instead" #-} where

foo :: Int
foo = 23
