module Bug4 where
-- | don't use apostrophe's in the wrong place's
foo :: Int

