-- #hide
module A where { data T = MkT; f :: T; f = MkT }
