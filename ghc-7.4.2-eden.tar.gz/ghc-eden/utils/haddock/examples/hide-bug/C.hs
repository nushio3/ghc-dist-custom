module C(C.bla) where 

import D

bla :: Test
bla = undefined
