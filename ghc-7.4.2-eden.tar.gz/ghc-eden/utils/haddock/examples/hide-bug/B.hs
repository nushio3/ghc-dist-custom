module B(Test, vis) where 

vis = id

data Test = Test
