-- The link to the type T in the doc for this module should point to 
-- B.T, not A.T.  Bug fixed in rev 1.59 of Main.hs.
module D(Test, hej) where 

import B

hej = vis
