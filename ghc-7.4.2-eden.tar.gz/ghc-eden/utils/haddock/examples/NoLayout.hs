module NoLayout where {
  -- | the class 'C'
  g :: Int;
 }
