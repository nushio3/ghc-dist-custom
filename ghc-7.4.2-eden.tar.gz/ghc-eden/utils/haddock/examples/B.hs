module B ( module A ) where
import A
