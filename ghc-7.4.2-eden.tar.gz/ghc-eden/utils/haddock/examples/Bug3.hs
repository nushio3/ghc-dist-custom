module Bug3 where

-- | /multi-line
-- emphasis/
foo :: Int

