module A where
data A = A
