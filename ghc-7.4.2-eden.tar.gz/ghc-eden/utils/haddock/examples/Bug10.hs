-- | Module: M
f :: a -> a

