#!/bin/sh

mkdir -p ${1+"$@"}

